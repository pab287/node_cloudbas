const baseUtils = require('./utils'); // the original file

const parseHexToTime = (hex)=>{ 
    return { year: 2000 + hex.readUIntLE(0,1), 
        month:hex.readUIntLE(1,1),
        date: hex.readUIntLE(2,1),
        hour: hex.readUIntLE(3,1),
        minute: hex.readUIntLE(4,1),
        second: hex.readUIntLE(5,1) 
    } 
}

function decodeRecordData40(recordData) {
    const record = baseUtils.decodeRecordData40(recordData);
    record.isState = 1;
    try{ record.verifyMethod = recordData.readUInt32LE(31); }
    catch(err){ record.verifyMethod = 0; }
    return record;
}

function decodeRecordRealTimeLog52(recordData) {
    const payload = baseUtils.removeTcpHeader(recordData);
    const record = baseUtils.decodeRecordRealTimeLog52(recordData);
    try{
        const recvData = payload.subarray(8);
        const timeBuffer = recvData.subarray(26, 26 + 6); 

        record.attState = recordData.readUInt8(24);
        record.verifyMethod = recordData.readUInt8(25);
        record.datetime = parseHexToTime(timeBuffer);
    } catch(err) {
        record.attState = 1;
        record.verifyMethod = 0;
        record.datetime = {};
    }
    return record;
}

module.exports = { ...baseUtils, decodeRecordData40, decodeRecordRealTimeLog52 };